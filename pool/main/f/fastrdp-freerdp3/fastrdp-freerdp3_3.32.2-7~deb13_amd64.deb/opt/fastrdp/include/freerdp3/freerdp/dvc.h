/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * Dynamic Virtual Channel Interface
 *
 * Copyright 2010-2011 Vic Lee
 * Copyright 2015 Thincast Technologies GmbH
 * Copyright 2015 DI (FH) Martin Haimberger <martin.haimberger@thincast.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * DVC Plugin API: See the original MS DVC Client API:
 * http://msdn.microsoft.com/en-us/library/bb540880%28v=VS.85%29.aspx
 *
 * The FreeRDP DVC Plugin API is a simulation of the MS DVC Client API in C.
 * The main difference is that every interface method must take an instance
 * pointer as the first parameter.
 */

/**
 * Implemented by DRDYNVC:
 * o IWTSVirtualChannelManager
 * o IWTSListener
 * o IWTSVirtualChannel
 *
 * Implemented by DVC plugin:
 * o IWTSPlugin
 * o IWTSListenerCallback
 * o IWTSVirtualChannelCallback
 *
 * A basic DVC plugin implementation:
 * 1. DVCPluginEntry:
 *    The plugin entry point, which creates and initializes a new IWTSPlugin
 *    instance
 * 2. IWTSPlugin.Initialize:
 *    Call IWTSVirtualChannelManager.CreateListener with a newly created
 *    IWTSListenerCallback instance
 * 3. IWTSListenerCallback.OnNewChannelConnection:
 *    Create IWTSVirtualChannelCallback instance if the new channel is accepted
 */

#ifndef FREERDP_DVC_H
#define FREERDP_DVC_H

#include <freerdp/types.h>
#include <freerdp/addin.h>
#include <freerdp/settings.h>

#ifdef __cplusplus
extern "C"
{
#endif

	typedef struct s_IWTSVirtualChannelManager IWTSVirtualChannelManager;
	typedef struct s_IWTSListener IWTSListener;
	typedef struct s_IWTSVirtualChannel IWTSVirtualChannel;

	typedef struct s_IWTSPlugin IWTSPlugin;
	typedef struct s_IWTSListenerCallback IWTSListenerCallback;
	typedef struct s_IWTSVirtualChannelCallback IWTSVirtualChannelCallback;

	struct s_IWTSListener
	{
		/* Retrieves the listener-specific configuration. */
		WINPR_ATTR_NODISCARD UINT (*GetConfiguration)(IWTSListener* pListener,
		                                              void** ppPropertyBag);

		void* pInterface;
	};

	struct s_IWTSVirtualChannel
	{
		/* Starts a write request on the channel. */
		WINPR_ATTR_NODISCARD UINT (*Write)(IWTSVirtualChannel* pChannel, ULONG cbSize,
		                                   const BYTE* pBuffer, void* pReserved);
		/* Closes the channel. */
		WINPR_ATTR_NODISCARD UINT (*Close)(IWTSVirtualChannel* pChannel);
	};

	struct s_IWTSVirtualChannelManager
	{
		/* Returns an instance of a listener object that listens on a specific
		   endpoint, or creates a static channel. */
		WINPR_ATTR_NODISCARD UINT (*CreateListener)(IWTSVirtualChannelManager* pChannelMgr,
		                                            const char* pszChannelName, ULONG ulFlags,
		                                            IWTSListenerCallback* pListenerCallback,
		                                            IWTSListener** ppListener);
		/* Find the channel or ID to send data to a specific endpoint. */
		WINPR_ATTR_NODISCARD UINT32 (*GetChannelId)(IWTSVirtualChannel* channel);
		WINPR_ATTR_NODISCARD IWTSVirtualChannel* (*FindChannelById)(
		    IWTSVirtualChannelManager* pChannelMgr, UINT32 ChannelId);
		WINPR_ATTR_NODISCARD const char* (*GetChannelName)(IWTSVirtualChannel* channel);
		UINT (*DestroyListener)(IWTSVirtualChannelManager* pChannelMgr, IWTSListener* ppListener);
	};

	struct s_IWTSPlugin
	{
		/* Used for the first call that is made from the client to the plug-in. */
		WINPR_ATTR_NODISCARD UINT (*Initialize)(IWTSPlugin* pPlugin,
		                                        IWTSVirtualChannelManager* pChannelMgr);
		/* Notifies the plug-in that the Remote Desktop Connection (RDC) client
		   has successfully connected to the Remote Desktop Session Host (RD
		   Session Host) server. */
		WINPR_ATTR_NODISCARD UINT (*Connected)(IWTSPlugin* pPlugin);
		/* Notifies the plug-in that the Remote Desktop Connection (RDC) client
		   has disconnected from the RD Session Host server. */
		WINPR_ATTR_NODISCARD UINT (*Disconnected)(IWTSPlugin* pPlugin, DWORD dwDisconnectCode);
		/* Notifies the plug-in that the Remote Desktop Connection (RDC) client
		   has terminated. */
		WINPR_ATTR_NODISCARD UINT (*Terminated)(IWTSPlugin* pPlugin);

		WINPR_ATTR_NODISCARD UINT (*Attached)(IWTSPlugin* pPlugin);

		WINPR_ATTR_NODISCARD UINT (*Detached)(IWTSPlugin* pPlugin);

		/* Extended */

		void* pInterface;
	};

	struct s_IWTSListenerCallback
	{
		/* Accepts or denies a connection request for an incoming connection to
		   the associated listener. */
		WINPR_ATTR_NODISCARD
		UINT (*OnNewChannelConnection)(IWTSListenerCallback* pListenerCallback,
		                               IWTSVirtualChannel* pChannel, BYTE* Data, BOOL* pbAccept,
		                               IWTSVirtualChannelCallback** ppCallback);

		void* pInterface;
	};

	struct s_IWTSVirtualChannelCallback
	{
		WINPR_ATTR_NODISCARD UINT (*OnDataReceived)(
		    IWTSVirtualChannelCallback* pChannelCallback,
		    wStream* data); /**< Notifies the user about data that is being received. */
		WINPR_ATTR_NODISCARD UINT (*OnOpen)(
		    IWTSVirtualChannelCallback*
		        pChannelCallback); /**< Notifies the user that the channel has been opened. */
		WINPR_ATTR_NODISCARD UINT (*OnClose)(
		    IWTSVirtualChannelCallback*
		        pChannelCallback); /**< Notifies the user that the channel has been closed. */

		void* pInterface;
	};

	/* The DVC Plugin entry points */
	typedef struct rdp_context rdpContext; /* forward declaration, necessary to avoid
	                                        * circular includes */

	typedef struct S_IDRDYNVC_ENTRY_POINTS IDRDYNVC_ENTRY_POINTS;
	struct S_IDRDYNVC_ENTRY_POINTS
	{
		WINPR_ATTR_NODISCARD UINT (*RegisterPlugin)(IDRDYNVC_ENTRY_POINTS* pEntryPoints,
		                                            const char* name, IWTSPlugin* pPlugin);
		IWTSPlugin* (*GetPlugin)(IDRDYNVC_ENTRY_POINTS* pEntryPoints, const char* name);
		const ADDIN_ARGV* (*GetPluginData)(IDRDYNVC_ENTRY_POINTS* pEntryPoints);
		WINPR_ATTR_NODISCARD rdpSettings* (*GetRdpSettings)(IDRDYNVC_ENTRY_POINTS* pEntryPoints);
		WINPR_ATTR_NODISCARD rdpContext* (*GetRdpContext)(IDRDYNVC_ENTRY_POINTS* pEntryPoints);
	};

	typedef UINT(VCAPITYPE* PDVC_PLUGIN_ENTRY)(IDRDYNVC_ENTRY_POINTS*);

	WINPR_ATTR_NODISCARD
	FREERDP_API void* get_callback_by_name(const char* name, void** context);
	FREERDP_API void add_callback_by_name(const char* name, void* fkt, void* context);
	FREERDP_API void remove_callback_by_name(const char* name, void* context);

#ifdef __cplusplus
}
#endif

#endif /* FREERDP_DVC_H */

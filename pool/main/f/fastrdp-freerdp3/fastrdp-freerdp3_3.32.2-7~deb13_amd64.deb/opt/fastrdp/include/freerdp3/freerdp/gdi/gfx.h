/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * GDI Graphics Pipeline
 *
 * Copyright 2014 Marc-Andre Moreau <marcandre.moreau@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef FREERDP_GDI_GFX_H
#define FREERDP_GDI_GFX_H

#include <freerdp/api.h>
#include <freerdp/gdi/gdi.h>

#ifdef __cplusplus
extern "C"
{
#endif

	struct gdi_gfx_surface
	{
		UINT16 surfaceId;
		rdpCodecs* codecs;
		H264_CONTEXT* h264;
		UINT32 width;
		UINT32 height;
		UINT32 mappedWidth;
		UINT32 mappedHeight;
		BYTE* data;
		UINT32 scanline;
		UINT32 format;
		BOOL outputMapped;
		UINT32 outputOriginX;
		UINT32 outputOriginY;
		REGION16 invalidRegion;
		UINT64 windowId;
		UINT32 outputTargetWidth;
		UINT32 outputTargetHeight;
		BOOL windowMapped;
		BOOL handleInUpdateSurfaceArea;
#if defined(WITH_GFX_AV1)
		FREERDP_AV1_CONTEXT* av1; /** @since version 3.25.0 */
#else
	    void* reservedAV1;
#endif
	};
	typedef struct gdi_gfx_surface gdiGfxSurface;

	struct gdi_gfx_cache_entry
	{
		UINT64 cacheKey;
		UINT32 width;
		UINT32 height;
		BYTE* data;
		UINT32 scanline;
		UINT32 format;
	};
	typedef struct gdi_gfx_cache_entry gdiGfxCacheEntry;

	FREERDP_API BOOL gdi_graphics_pipeline_init(rdpGdi* gdi, RdpgfxClientContext* gfx);

	FREERDP_API BOOL gdi_graphics_pipeline_init_ex(rdpGdi* gdi, RdpgfxClientContext* gfx,
	                                               pcRdpgfxMapWindowForSurface map,
	                                               pcRdpgfxUnmapWindowForSurface unmap,
	                                               pcRdpgfxUpdateSurfaceArea update);
	FREERDP_API void gdi_graphics_pipeline_uninit(rdpGdi* gdi, RdpgfxClientContext* gfx);

#ifdef __cplusplus
}
#endif

#endif /* FREERDP_GDI_GFX_H */

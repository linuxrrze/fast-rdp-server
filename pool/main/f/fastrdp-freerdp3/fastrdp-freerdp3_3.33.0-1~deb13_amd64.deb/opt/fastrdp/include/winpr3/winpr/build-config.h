#ifndef WINPR_BUILD_CONFIG_H
#define WINPR_BUILD_CONFIG_H

#define WINPR_DATA_PATH ""
#define WINPR_KEYMAP_PATH ""
#define WINPR_PLUGIN_PATH ""

#define WINPR_INSTALL_PREFIX "/opt/fastrdp"
#define WINPR_INSTALL_SYSCONFDIR "/etc/opt/fastrdp"
#define WINPR_INSTALL_LOCALEDIR "/opt/fastrdp/share/locale"

#define WINPR_LIBRARY_PATH ""

#define WINPR_ADDIN_PATH ""

#define WINPR_SHARED_LIBRARY_SUFFIX ".so"
#define WINPR_SHARED_LIBRARY_PREFIX  "lib"

#define WINPR_VENDOR_STRING "FreeRDP"
#define WINPR_PRODUCT_STRING "FreeRDP"

#define WINPR_PROXY_PLUGINDIR ""

#endif /* WINPR_BUILD_CONFIG_H */

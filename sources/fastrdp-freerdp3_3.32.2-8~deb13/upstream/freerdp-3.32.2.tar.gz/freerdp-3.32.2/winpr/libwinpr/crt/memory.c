/**
 * WinPR: Windows Portable Runtime
 * Memory Allocation
 *
 * Copyright 2012 Marc-Andre Moreau <marcandre.moreau@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <winpr/config.h>

#include <winpr/crt.h>

/* Memory Allocation: http://msdn.microsoft.com/en-us/library/hk1k7x6x.aspx */
/* Memory Management Functions: http://msdn.microsoft.com/en-us/library/windows/desktop/aa366781/ */

#ifndef _WIN32

PVOID SecureZeroMemory(PVOID ptr, size_t cnt)
{
	volatile BYTE* p = ptr;

	while (cnt--)
	{
		*p = 0;
		p++;
	}

	return ptr;
}

#endif

void winpr_zfree(char* str)
{
	if (str)
	{
		char* cur = str;
		while (*cur != '\0')
			*cur++ = '\0';
	}
	free(str);
}

void winpr_znfree(void* data, size_t len)
{
	WINPR_ASSERT(data || (len == 0));
	if (data)
		memset(data, 0, len);
	free(data);
}

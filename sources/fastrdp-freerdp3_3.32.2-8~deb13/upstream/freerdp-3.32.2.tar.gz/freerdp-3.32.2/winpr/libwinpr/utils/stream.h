/*
 * WinPR: Windows Portable Runtime
 * Stream Utils
 *
 * Copyright 2021 Armin Novak <anovak@thincast.com>
 * Copyright 2021 Thincast Technologies GmbH
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef LIBWINPR_UTILS_STREAM_H
#define LIBWINPR_UTILS_STREAM_H

#include <winpr/stream.h>

void Stream_EnsureValidity(wStream* s);
BOOL Stream_ResizeToCapacity(wStream* s, size_t size);

#endif /* LIBWINPR_UTILS_STREAM_H */

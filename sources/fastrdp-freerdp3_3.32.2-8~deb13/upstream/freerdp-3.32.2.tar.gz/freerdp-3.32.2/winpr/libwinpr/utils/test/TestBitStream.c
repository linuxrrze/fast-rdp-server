
#include <winpr/crt.h>
#include <winpr/print.h>
#include <winpr/stream.h>
#include <winpr/bitstream.h>

static void BitStrGen(void)
{
	char str[64] = WINPR_C_ARRAY_INIT;

	for (DWORD i = 0; i < 256;)
	{
		printf("\t");

		for (DWORD j = 0; j < 4; j++)
		{
			if (0)
			{
				/* Least Significant Bit First */
				str[0] = (i & (1u << 7)) ? '1' : '0';
				str[1] = (i & (1u << 6)) ? '1' : '0';
				str[2] = (i & (1u << 5)) ? '1' : '0';
				str[3] = (i & (1u << 4)) ? '1' : '0';
				str[4] = (i & (1u << 3)) ? '1' : '0';
				str[5] = (i & (1u << 2)) ? '1' : '0';
				str[6] = (i & (1u << 1)) ? '1' : '0';
				str[7] = (i & (1u << 0)) ? '1' : '0';
				str[8] = '\0';
			}
			else
			{
				/* Most Significant Bit First */
				str[7] = (i & (1u << 7)) ? '1' : '0';
				str[6] = (i & (1u << 6)) ? '1' : '0';
				str[5] = (i & (1u << 5)) ? '1' : '0';
				str[4] = (i & (1u << 4)) ? '1' : '0';
				str[3] = (i & (1u << 3)) ? '1' : '0';
				str[2] = (i & (1u << 2)) ? '1' : '0';
				str[1] = (i & (1u << 1)) ? '1' : '0';
				str[0] = (i & (1u << 0)) ? '1' : '0';
				str[8] = '\0';
			}

			printf("\"%s\",%s", str, j == 3 ? "" : " ");
			i++;
		}

		printf("\n");
	}
}

int TestBitStream(int argc, char* argv[])
{
	wBitStream* bs = nullptr;
	BYTE buffer[1024] = WINPR_C_ARRAY_INIT;

	WINPR_UNUSED(argc);
	WINPR_UNUSED(argv);

	bs = BitStream_New();
	if (!bs)
		return 1;
	BitStream_Attach(bs, buffer, sizeof(buffer));
	BitStream_Write_Bits(bs, 0xAF, 8); /* 11110101 */
	BitStream_Write_Bits(bs, 0xF, 4);  /* 1111 */
	BitStream_Write_Bits(bs, 0xA, 4);  /* 0101 */
	BitStream_Flush(bs);
	BitDump(__func__, WLOG_INFO, buffer, bs->position, BITDUMP_MSB_FIRST);
	BitStream_Write_Bits(bs, 3, 2);    /* 11 */
	BitStream_Write_Bits(bs, 0, 3);    /* 000 */
	BitStream_Write_Bits(bs, 0x2D, 6); /* 101101 */
	BitStream_Write_Bits(bs, 0x19, 5); /* 11001 */
	// BitStream_Flush(bs); /* flush should be done automatically here (32 bits written) */
	BitDump(__func__, WLOG_INFO, buffer, bs->position, BITDUMP_MSB_FIRST);
	BitStream_Write_Bits(bs, 3, 2); /* 11 */
	BitStream_Flush(bs);
	BitDump(__func__, WLOG_INFO, buffer, bs->position, BITDUMP_MSB_FIRST);
	BitStream_Write_Bits(bs, 00, 2);  /* 00 */
	BitStream_Write_Bits(bs, 0xF, 4); /* 1111 */
	BitStream_Write_Bits(bs, 0, 20);
	BitStream_Write_Bits(bs, 0xAFF, 12); /* 111111110101 */
	BitStream_Flush(bs);
	BitDump(__func__, WLOG_INFO, buffer, bs->position, BITDUMP_MSB_FIRST);
	BitStream_Free(bs);
	return 0;
}

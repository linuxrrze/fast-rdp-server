/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * Security Support Provider Interface (SSPI)
 *
 * Copyright 2012-2014 Marc-Andre Moreau <marcandre.moreau@gmail.com>
 * Copyright 2017 Dorian Ducournau <dorian.ducournau@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <winpr/config.h>
#include <winpr/assert.h>
#include <winpr/windows.h>

#include <winpr/crt.h>
#include <winpr/synch.h>
#include <winpr/sspi.h>
#include <winpr/ssl.h>
#include <winpr/print.h>

#include "sspi.h"

#include "sspi_winpr.h"

#include "../utils.h"
#include "../log.h"
#define TAG WINPR_TAG("sspi")

/* Authentication Functions: http://msdn.microsoft.com/en-us/library/windows/desktop/aa374731/ */

#include "NTLM/ntlm.h"
#include "NTLM/ntlm_export.h"
#include "CredSSP/credssp.h"
#include "Kerberos/kerberos.h"
#include "Negotiate/negotiate.h"
#include "Schannel/schannel.h"

static const SecPkgInfoA* SecPkgInfoA_LIST[] = { &NTLM_SecPkgInfoA, &KERBEROS_SecPkgInfoA,
	                                             &NEGOTIATE_SecPkgInfoA, &CREDSSP_SecPkgInfoA,
	                                             &SCHANNEL_SecPkgInfoA };

static const SecPkgInfoW* SecPkgInfoW_LIST[] = { &NTLM_SecPkgInfoW, &KERBEROS_SecPkgInfoW,
	                                             &NEGOTIATE_SecPkgInfoW, &CREDSSP_SecPkgInfoW,
	                                             &SCHANNEL_SecPkgInfoW };

typedef struct
{
	const SEC_CHAR* Name;
	const SecurityFunctionTableA* SecurityFunctionTable;
} SecurityFunctionTableA_NAME;

typedef struct
{
	const SEC_WCHAR* Name;
	const SecurityFunctionTableW* SecurityFunctionTable;
} SecurityFunctionTableW_NAME;

static const SecurityFunctionTableA_NAME SecurityFunctionTableA_NAME_LIST[] = {
	{ "NTLM", &NTLM_SecurityFunctionTableA },
	{ "Kerberos", &KERBEROS_SecurityFunctionTableA },
	{ "Negotiate", &NEGOTIATE_SecurityFunctionTableA },
	{ "CREDSSP", &CREDSSP_SecurityFunctionTableA },
	{ "Schannel", &SCHANNEL_SecurityFunctionTableA }
};

static WCHAR BUFFER_NAME_LIST_W[5][32] = WINPR_C_ARRAY_INIT;

static const SecurityFunctionTableW_NAME SecurityFunctionTableW_NAME_LIST[] = {
	{ BUFFER_NAME_LIST_W[0], &NTLM_SecurityFunctionTableW },
	{ BUFFER_NAME_LIST_W[1], &KERBEROS_SecurityFunctionTableW },
	{ BUFFER_NAME_LIST_W[2], &NEGOTIATE_SecurityFunctionTableW },
	{ BUFFER_NAME_LIST_W[3], &CREDSSP_SecurityFunctionTableW },
	{ BUFFER_NAME_LIST_W[4], &SCHANNEL_SecurityFunctionTableW }
};

typedef struct
{
	void* contextBuffer;
	UINT32 allocatorIndex;
} CONTEXT_BUFFER_ALLOC_ENTRY;

typedef struct
{
	UINT32 cEntries;
	UINT32 cMaxEntries;
	CONTEXT_BUFFER_ALLOC_ENTRY* entries;
} CONTEXT_BUFFER_ALLOC_TABLE;

static CONTEXT_BUFFER_ALLOC_TABLE ContextBufferAllocTable = WINPR_C_ARRAY_INIT;

/* The table is shared by all threads of the process, every access must hold this lock */
static CRITICAL_SECTION ContextBufferAllocTableLock = WINPR_C_ARRAY_INIT;

static int sspi_ContextBufferAllocTableNew(void)
{
	size_t size = 0;

	if (!InitializeCriticalSectionEx(&ContextBufferAllocTableLock, 0, 0))
		return -1;

	ContextBufferAllocTable.entries = nullptr;
	ContextBufferAllocTable.cEntries = 0;
	ContextBufferAllocTable.cMaxEntries = 4;
	size = sizeof(CONTEXT_BUFFER_ALLOC_ENTRY) * ContextBufferAllocTable.cMaxEntries;
	ContextBufferAllocTable.entries = (CONTEXT_BUFFER_ALLOC_ENTRY*)calloc(1, size);

	if (!ContextBufferAllocTable.entries)
	{
		DeleteCriticalSection(&ContextBufferAllocTableLock);
		return -1;
	}

	return 1;
}

/* NB: ContextBufferAllocTableLock must be held by the caller */
static int sspi_ContextBufferAllocTableGrow(void)
{
	size_t size = 0;
	CONTEXT_BUFFER_ALLOC_ENTRY* entries = nullptr;
	const UINT32 cMaxEntries = ContextBufferAllocTable.cMaxEntries + 128ull;
	size = sizeof(CONTEXT_BUFFER_ALLOC_ENTRY) * cMaxEntries;

	if (!size)
		return -1;

	entries = (CONTEXT_BUFFER_ALLOC_ENTRY*)realloc(ContextBufferAllocTable.entries, size);

	/* on failure the old table (and the buffers it tracks) stays valid */
	if (!entries)
		return -1;

	ContextBufferAllocTable.cMaxEntries = cMaxEntries;
	ContextBufferAllocTable.entries = entries;
	ZeroMemory((void*)&ContextBufferAllocTable.entries[ContextBufferAllocTable.cMaxEntries / 2],
	           size / 2);
	return 1;
}

static void sspi_ContextBufferAllocTableFree(void)
{
	if (ContextBufferAllocTable.cEntries != 0)
		WLog_ERR(TAG, "ContextBufferAllocTable.entries == %" PRIu32,
		         ContextBufferAllocTable.cEntries);

	ContextBufferAllocTable.cEntries = ContextBufferAllocTable.cMaxEntries = 0;
	free(ContextBufferAllocTable.entries);
	ContextBufferAllocTable.entries = nullptr;
	DeleteCriticalSection(&ContextBufferAllocTableLock);
}

/* NB: ContextBufferAllocTableLock must be held by the caller */
static void* sspi_ContextBufferAllocLocked(UINT32 allocatorIndex, size_t size)
{
	void* contextBuffer = nullptr;

	for (UINT32 index = 0; index < ContextBufferAllocTable.cMaxEntries; index++)
	{
		if (!ContextBufferAllocTable.entries[index].contextBuffer)
		{
			contextBuffer = calloc(1, size);

			if (!contextBuffer)
				return nullptr;

			ContextBufferAllocTable.cEntries++;
			ContextBufferAllocTable.entries[index].contextBuffer = contextBuffer;
			ContextBufferAllocTable.entries[index].allocatorIndex = allocatorIndex;
			return ContextBufferAllocTable.entries[index].contextBuffer;
		}
	}

	/* no available entry was found, the table needs to be grown */

	if (sspi_ContextBufferAllocTableGrow() < 0)
		return nullptr;

	/* the next call to sspi_ContextBufferAllocLocked() should now succeed */
	return sspi_ContextBufferAllocLocked(allocatorIndex, size);
}

void* sspi_ContextBufferAlloc(UINT32 allocatorIndex, size_t size)
{
	EnterCriticalSection(&ContextBufferAllocTableLock);
	void* contextBuffer = sspi_ContextBufferAllocLocked(allocatorIndex, size);
	LeaveCriticalSection(&ContextBufferAllocTableLock);
	return contextBuffer;
}

SSPI_CREDENTIALS* sspi_CredentialsNew(void)
{
	SSPI_CREDENTIALS* credentials = (SSPI_CREDENTIALS*)calloc(1, sizeof(SSPI_CREDENTIALS));
	if (!credentials)
		return nullptr;

	credentials->ntlmSettingsV2 = sspi_AllocSecNtlmSettings();
	if (!credentials->ntlmSettingsV2)
	{
		sspi_CredentialsFree(credentials);
		return nullptr;
	}

	return credentials;
}

void sspi_CredentialsFree(SSPI_CREDENTIALS* credentials)
{
	if (!credentials)
		return;

	size_t userLength = credentials->identity.UserLength;
	size_t domainLength = credentials->identity.DomainLength;
	size_t passwordLength = credentials->identity.PasswordLength;

	if (credentials->identity.Flags & SEC_WINNT_AUTH_IDENTITY_UNICODE)
	{
		userLength *= 2;
		domainLength *= 2;
		passwordLength *= 2;
	}

	if (credentials->identity.User)
		memset(credentials->identity.User, 0, userLength);
	if (credentials->identity.Domain)
		memset(credentials->identity.Domain, 0, domainLength);
	if (credentials->identity.Password)
		memset(credentials->identity.Password, 0, passwordLength);
	free(credentials->identity.User);
	free(credentials->identity.Domain);
	free(credentials->identity.Password);
	sspi_FreeSecNtlmSettings(credentials->ntlmSettingsV2);

	free(credentials);
}

void* sspi_SecBufferAlloc(PSecBuffer SecBuffer, ULONG size)
{
	if (!SecBuffer)
		return nullptr;

	SecBuffer->pvBuffer = calloc(1, size);

	if (!SecBuffer->pvBuffer)
		return nullptr;

	SecBuffer->cbBuffer = size;
	return SecBuffer->pvBuffer;
}

void sspi_SecBufferFree(PSecBuffer SecBuffer)
{
	if (!SecBuffer)
		return;

	if (SecBuffer->pvBuffer)
		memset(SecBuffer->pvBuffer, 0, SecBuffer->cbBuffer);

	free(SecBuffer->pvBuffer);
	SecBuffer->pvBuffer = nullptr;
	SecBuffer->cbBuffer = 0;
}

SecHandle* sspi_SecureHandleAlloc(void)
{
	SecHandle* handle = (SecHandle*)calloc(1, sizeof(SecHandle));

	if (!handle)
		return nullptr;

	SecInvalidateHandle(handle);
	return handle;
}

void* sspi_SecureHandleGetLowerPointer(SecHandle* handle)
{
	void* pointer = nullptr;

	if (!handle || !SecIsValidHandle(handle) || !handle->dwLower)
		return nullptr;

	pointer = (void*)~((size_t)handle->dwLower);
	return pointer;
}

void sspi_SecureHandleInvalidate(SecHandle* handle)
{
	if (!handle)
		return;

	handle->dwLower = 0;
	handle->dwUpper = 0;
}

void sspi_SecureHandleSetLowerPointer(SecHandle* handle, void* pointer)
{
	if (!handle)
		return;

	handle->dwLower = (ULONG_PTR)(~((size_t)pointer));
}

void* sspi_SecureHandleGetUpperPointer(SecHandle* handle)
{
	void* pointer = nullptr;

	if (!handle || !SecIsValidHandle(handle) || !handle->dwUpper)
		return nullptr;

	pointer = (void*)~((size_t)handle->dwUpper);
	return pointer;
}

void sspi_SecureHandleSetUpperPointer(SecHandle* handle, void* pointer)
{
	if (!handle)
		return;

	handle->dwUpper = (ULONG_PTR)(~((size_t)pointer));
}

SSPI_PACKAGE_ID sspi_SecureHandleGetPackageId(SecHandle* handle)
{
	if (!handle || !SecIsValidHandle(handle) || !handle->dwUpper)
		return SSPI_PACKAGE_NONE;

	return (SSPI_PACKAGE_ID)(~((size_t)handle->dwUpper));
}

void sspi_SecureHandleSetPackageId(SecHandle* handle, SSPI_PACKAGE_ID id)
{
	if (!handle)
		return;

	handle->dwUpper = (ULONG_PTR)(~((size_t)id));
}

void sspi_SecureHandleFree(SecHandle* handle)
{
	free(handle);
}

int sspi_SetAuthIdentityW(SEC_WINNT_AUTH_IDENTITY* identity, const WCHAR* user, const WCHAR* domain,
                          const WCHAR* password)
{
	return sspi_SetAuthIdentityWithLengthW(identity, user, user ? _wcslen(user) : 0, domain,
	                                       domain ? _wcslen(domain) : 0, password,
	                                       password ? _wcslen(password) : 0);
}

static BOOL copy(WCHAR** dst, ULONG* dstLen, const WCHAR* what, size_t len)
{
	WINPR_ASSERT(dst);
	WINPR_ASSERT(dstLen);

	*dst = nullptr;
	*dstLen = 0;

	if (len > UINT32_MAX)
		return FALSE;

	/* Case what="" and len=0 should allocate an empty string */
	if (!what && (len != 0))
		return FALSE;
	if (!what && (len == 0))
		return TRUE;

	*dst = calloc(sizeof(WCHAR), len + 1);
	if (!*dst)
		return FALSE;

	memcpy(*dst, what, len * sizeof(WCHAR));
	*dstLen = WINPR_ASSERTING_INT_CAST(UINT32, len);
	return TRUE;
}

int sspi_SetAuthIdentityWithLengthW(SEC_WINNT_AUTH_IDENTITY* identity, const WCHAR* user,
                                    size_t userLen, const WCHAR* domain, size_t domainLen,
                                    const WCHAR* password, size_t passwordLen)
{
	WINPR_ASSERT(identity);
	sspi_FreeAuthIdentity(identity);
	identity->Flags &= (uint32_t)~SEC_WINNT_AUTH_IDENTITY_ANSI;
	identity->Flags |= SEC_WINNT_AUTH_IDENTITY_UNICODE;

	if (!copy(&identity->User, &identity->UserLength, user, userLen))
		return -1;

	if (!copy(&identity->Domain, &identity->DomainLength, domain, domainLen))
		return -1;

	if (!copy(&identity->Password, &identity->PasswordLength, password, passwordLen))
		return -1;

	return 1;
}

int sspi_SetAuthIdentityA(SEC_WINNT_AUTH_IDENTITY* identity, const char* user, const char* domain,
                          const char* password)
{
	int rc = 0;
	size_t unicodeUserLenW = 0;
	size_t unicodeDomainLenW = 0;
	size_t unicodePasswordLenW = 0;
	LPWSTR unicodeUser = nullptr;
	LPWSTR unicodeDomain = nullptr;
	LPWSTR unicodePassword = nullptr;

	if (user)
		unicodeUser = ConvertUtf8ToWCharAlloc(user, &unicodeUserLenW);

	if (domain)
		unicodeDomain = ConvertUtf8ToWCharAlloc(domain, &unicodeDomainLenW);

	if (password)
		unicodePassword = ConvertUtf8ToWCharAlloc(password, &unicodePasswordLenW);

	rc = sspi_SetAuthIdentityWithLengthW(identity, unicodeUser, unicodeUserLenW, unicodeDomain,
	                                     unicodeDomainLenW, unicodePassword, unicodePasswordLenW);

	winpr_znfree(unicodeUser, unicodeUserLenW * sizeof(WCHAR));
	winpr_znfree(unicodeDomain, unicodeDomainLenW * sizeof(WCHAR));
	winpr_znfree(unicodePassword, unicodePasswordLenW * sizeof(WCHAR));
	return rc;
}

UINT32 sspi_GetAuthIdentityVersion(const void* identity)
{
	UINT32 version = 0;

	if (!identity)
		return 0;

	version = *((const UINT32*)identity);

	if ((version == SEC_WINNT_AUTH_IDENTITY_VERSION) ||
	    (version == SEC_WINNT_AUTH_IDENTITY_VERSION_2))
	{
		return version;
	}

	return 0; // SEC_WINNT_AUTH_IDENTITY (no version)
}

UINT32 sspi_GetAuthIdentityFlags(const void* identity)
{
	UINT32 version = 0;
	UINT32 flags = 0;

	if (!identity)
		return 0;

	version = sspi_GetAuthIdentityVersion(identity);

	if (version == SEC_WINNT_AUTH_IDENTITY_VERSION)
	{
		flags = ((const SEC_WINNT_AUTH_IDENTITY_EX*)identity)->Flags;
	}
	else if (version == SEC_WINNT_AUTH_IDENTITY_VERSION_2)
	{
		flags = ((const SEC_WINNT_AUTH_IDENTITY_EX2*)identity)->Flags;
	}
	else // SEC_WINNT_AUTH_IDENTITY
	{
		flags = ((const SEC_WINNT_AUTH_IDENTITY*)identity)->Flags;
	}

	return flags;
}

BOOL sspi_GetAuthIdentityUserDomainW(const void* identity, const WCHAR** pUser, UINT32* pUserLength,
                                     const WCHAR** pDomain, UINT32* pDomainLength)
{
	UINT32 version = 0;

	if (!identity)
		return FALSE;

	version = sspi_GetAuthIdentityVersion(identity);

	if (version == SEC_WINNT_AUTH_IDENTITY_VERSION)
	{
		const SEC_WINNT_AUTH_IDENTITY_EXW* id = (const SEC_WINNT_AUTH_IDENTITY_EXW*)identity;
		*pUser = (const WCHAR*)id->User;
		*pUserLength = id->UserLength;
		*pDomain = (const WCHAR*)id->Domain;
		*pDomainLength = id->DomainLength;
	}
	else if (version == SEC_WINNT_AUTH_IDENTITY_VERSION_2)
	{
		const SEC_WINNT_AUTH_IDENTITY_EX2* id = (const SEC_WINNT_AUTH_IDENTITY_EX2*)identity;
		UINT32 UserOffset = id->UserOffset;
		UINT32 DomainOffset = id->DomainOffset;
		*pUser = WINPR_PACKED_ALIGN_CAST(const WCHAR*, &((const uint8_t*)identity)[UserOffset]);
		*pUserLength = id->UserLength / 2;
		*pDomain = WINPR_PACKED_ALIGN_CAST(const WCHAR*, &((const uint8_t*)identity)[DomainOffset]);
		*pDomainLength = id->DomainLength / 2;
	}
	else // SEC_WINNT_AUTH_IDENTITY
	{
		const SEC_WINNT_AUTH_IDENTITY_W* id = (const SEC_WINNT_AUTH_IDENTITY_W*)identity;
		*pUser = (const WCHAR*)id->User;
		*pUserLength = id->UserLength;
		*pDomain = (const WCHAR*)id->Domain;
		*pDomainLength = id->DomainLength;
	}

	return TRUE;
}

BOOL sspi_GetAuthIdentityUserDomainA(const void* identity, const char** pUser, UINT32* pUserLength,
                                     const char** pDomain, UINT32* pDomainLength)
{
	UINT32 version = 0;

	if (!identity)
		return FALSE;

	version = sspi_GetAuthIdentityVersion(identity);

	if (version == SEC_WINNT_AUTH_IDENTITY_VERSION)
	{
		const SEC_WINNT_AUTH_IDENTITY_EXA* id = (const SEC_WINNT_AUTH_IDENTITY_EXA*)identity;
		*pUser = (const char*)id->User;
		*pUserLength = id->UserLength;
		*pDomain = (const char*)id->Domain;
		*pDomainLength = id->DomainLength;
	}
	else if (version == SEC_WINNT_AUTH_IDENTITY_VERSION_2)
	{
		const SEC_WINNT_AUTH_IDENTITY_EX2* id = (const SEC_WINNT_AUTH_IDENTITY_EX2*)identity;
		UINT32 UserOffset = id->UserOffset;
		UINT32 DomainOffset = id->DomainOffset;
		*pUser = (const char*)&((const uint8_t*)identity)[UserOffset];
		*pUserLength = id->UserLength;
		*pDomain = (const char*)&((const uint8_t*)identity)[DomainOffset];
		*pDomainLength = id->DomainLength;
	}
	else // SEC_WINNT_AUTH_IDENTITY
	{
		const SEC_WINNT_AUTH_IDENTITY_A* id = (const SEC_WINNT_AUTH_IDENTITY_A*)identity;
		*pUser = (const char*)id->User;
		*pUserLength = id->UserLength;
		*pDomain = (const char*)id->Domain;
		*pDomainLength = id->DomainLength;
	}

	return TRUE;
}

BOOL sspi_GetAuthIdentityPasswordW(const void* identity, const WCHAR** pPassword,
                                   UINT32* pPasswordLength)
{
	UINT32 version = 0;

	if (!identity)
		return FALSE;

	version = sspi_GetAuthIdentityVersion(identity);

	if (version == SEC_WINNT_AUTH_IDENTITY_VERSION)
	{
		const SEC_WINNT_AUTH_IDENTITY_EXW* id = (const SEC_WINNT_AUTH_IDENTITY_EXW*)identity;
		*pPassword = (const WCHAR*)id->Password;
		*pPasswordLength = id->PasswordLength;
	}
	else if (version == SEC_WINNT_AUTH_IDENTITY_VERSION_2)
	{
		return FALSE; // TODO: packed credentials
	}
	else // SEC_WINNT_AUTH_IDENTITY
	{
		const SEC_WINNT_AUTH_IDENTITY_W* id = (const SEC_WINNT_AUTH_IDENTITY_W*)identity;
		*pPassword = (const WCHAR*)id->Password;
		*pPasswordLength = id->PasswordLength;
	}

	return TRUE;
}

BOOL sspi_GetAuthIdentityPasswordA(const void* identity, const char** pPassword,
                                   UINT32* pPasswordLength)
{
	UINT32 version = 0;

	if (!identity)
		return FALSE;

	version = sspi_GetAuthIdentityVersion(identity);

	if (version == SEC_WINNT_AUTH_IDENTITY_VERSION)
	{
		const SEC_WINNT_AUTH_IDENTITY_EXA* id = (const SEC_WINNT_AUTH_IDENTITY_EXA*)identity;
		*pPassword = (const char*)id->Password;
		*pPasswordLength = id->PasswordLength;
	}
	else if (version == SEC_WINNT_AUTH_IDENTITY_VERSION_2)
	{
		return FALSE; // TODO: packed credentials
	}
	else // SEC_WINNT_AUTH_IDENTITY
	{
		const SEC_WINNT_AUTH_IDENTITY_A* id = (const SEC_WINNT_AUTH_IDENTITY_A*)identity;
		*pPassword = (const char*)id->Password;
		*pPasswordLength = id->PasswordLength;
	}

	return TRUE;
}

BOOL sspi_CopyAuthIdentityFieldsA(const SEC_WINNT_AUTH_IDENTITY_INFO* identity, char** pUser,
                                  char** pDomain, char** pPassword)
{
	BOOL success = FALSE;
	const char* UserA = nullptr;
	const char* DomainA = nullptr;
	const char* PasswordA = nullptr;
	const WCHAR* UserW = nullptr;
	const WCHAR* DomainW = nullptr;
	const WCHAR* PasswordW = nullptr;
	UINT32 UserLength = 0;
	UINT32 DomainLength = 0;
	UINT32 PasswordLength = 0;

	if (!identity || !pUser || !pDomain || !pPassword)
		return FALSE;

	*pUser = *pDomain = *pPassword = nullptr;

	UINT32 identityFlags = sspi_GetAuthIdentityFlags(identity);

	if ((identityFlags & SEC_WINNT_AUTH_IDENTITY_ANSI) != 0)
	{
		if (!sspi_GetAuthIdentityUserDomainA(identity, &UserA, &UserLength, &DomainA,
		                                     &DomainLength))
			goto cleanup;

		if (!sspi_GetAuthIdentityPasswordA(identity, &PasswordA, &PasswordLength))
			goto cleanup;

		if (UserA && UserLength)
		{
			*pUser = _strdup(UserA);

			if (!(*pUser))
				goto cleanup;
		}

		if (DomainA && DomainLength)
		{
			*pDomain = _strdup(DomainA);

			if (!(*pDomain))
				goto cleanup;
		}

		if (PasswordA && PasswordLength)
		{
			*pPassword = _strdup(PasswordA);

			if (!(*pPassword))
				goto cleanup;
		}

		success = TRUE;
	}
	else if ((identityFlags & SEC_WINNT_AUTH_IDENTITY_UNICODE) != 0)
	{
		if (!sspi_GetAuthIdentityUserDomainW(identity, &UserW, &UserLength, &DomainW,
		                                     &DomainLength))
			goto cleanup;

		if (!sspi_GetAuthIdentityPasswordW(identity, &PasswordW, &PasswordLength))
			goto cleanup;

		if (UserW && (UserLength > 0))
		{
			*pUser = ConvertWCharNToUtf8Alloc(UserW, UserLength, nullptr);
			if (!(*pUser))
				goto cleanup;
		}

		if (DomainW && (DomainLength > 0))
		{
			*pDomain = ConvertWCharNToUtf8Alloc(DomainW, DomainLength, nullptr);
			if (!(*pDomain))
				goto cleanup;
		}

		if (PasswordW && (PasswordLength > 0))
		{
			*pPassword = ConvertWCharNToUtf8Alloc(PasswordW, PasswordLength, nullptr);
			if (!(*pPassword))
				goto cleanup;
		}

		success = TRUE;
	}

cleanup:
	return success;
}

BOOL sspi_CopyAuthIdentityFieldsW(const SEC_WINNT_AUTH_IDENTITY_INFO* identity, WCHAR** pUser,
                                  WCHAR** pDomain, WCHAR** pPassword)
{
	BOOL success = FALSE;
	const char* UserA = nullptr;
	const char* DomainA = nullptr;
	const char* PasswordA = nullptr;
	const WCHAR* UserW = nullptr;
	const WCHAR* DomainW = nullptr;
	const WCHAR* PasswordW = nullptr;
	UINT32 UserLength = 0;
	UINT32 DomainLength = 0;
	UINT32 PasswordLength = 0;

	if (!identity || !pUser || !pDomain || !pPassword)
		return FALSE;

	*pUser = *pDomain = *pPassword = nullptr;

	UINT32 identityFlags = sspi_GetAuthIdentityFlags(identity);

	if ((identityFlags & SEC_WINNT_AUTH_IDENTITY_ANSI) != 0)
	{
		if (!sspi_GetAuthIdentityUserDomainA(identity, &UserA, &UserLength, &DomainA,
		                                     &DomainLength))
			goto cleanup;

		if (!sspi_GetAuthIdentityPasswordA(identity, &PasswordA, &PasswordLength))
			goto cleanup;

		if (UserA && (UserLength > 0))
		{
			WCHAR* ptr = ConvertUtf8NToWCharAlloc(UserA, UserLength, nullptr);
			*pUser = ptr;

			if (!ptr)
				goto cleanup;
		}

		if (DomainA && (DomainLength > 0))
		{
			WCHAR* ptr = ConvertUtf8NToWCharAlloc(DomainA, DomainLength, nullptr);
			*pDomain = ptr;
			if (!ptr)
				goto cleanup;
		}

		if (PasswordA && (PasswordLength > 0))
		{
			WCHAR* ptr = ConvertUtf8NToWCharAlloc(PasswordA, PasswordLength, nullptr);

			*pPassword = ptr;
			if (!ptr)
				goto cleanup;
		}

		success = TRUE;
	}
	else if ((identityFlags & SEC_WINNT_AUTH_IDENTITY_UNICODE) != 0)
	{
		if (!sspi_GetAuthIdentityUserDomainW(identity, &UserW, &UserLength, &DomainW,
		                                     &DomainLength))
			goto cleanup;

		if (!sspi_GetAuthIdentityPasswordW(identity, &PasswordW, &PasswordLength))
			goto cleanup;

		if (UserW && UserLength)
		{
			*pUser = winpr_wcsndup(UserW, UserLength / sizeof(WCHAR));

			if (!(*pUser))
				goto cleanup;
		}

		if (DomainW && DomainLength)
		{
			*pDomain = winpr_wcsndup(DomainW, DomainLength / sizeof(WCHAR));

			if (!(*pDomain))
				goto cleanup;
		}

		if (PasswordW && PasswordLength)
		{
			*pPassword = winpr_wcsndup(PasswordW, PasswordLength / sizeof(WCHAR));

			if (!(*pPassword))
				goto cleanup;
		}

		success = TRUE;
	}

cleanup:
	return success;
}

BOOL sspi_CopyAuthPackageListA(const SEC_WINNT_AUTH_IDENTITY_INFO* identity, char** pPackageList)
{
	UINT32 version = 0;
	UINT32 identityFlags = 0;
	char* PackageList = nullptr;
	const char* PackageListA = nullptr;
	const WCHAR* PackageListW = nullptr;
	UINT32 PackageListLength = 0;
	UINT32 PackageListOffset = 0;
	const void* pAuthData = (const void*)identity;

	if (!pAuthData)
		return FALSE;

	version = sspi_GetAuthIdentityVersion(pAuthData);
	identityFlags = sspi_GetAuthIdentityFlags(pAuthData);

	if ((identityFlags & SEC_WINNT_AUTH_IDENTITY_ANSI) != 0)
	{
		if (version == SEC_WINNT_AUTH_IDENTITY_VERSION)
		{
			const SEC_WINNT_AUTH_IDENTITY_EXA* ad = (const SEC_WINNT_AUTH_IDENTITY_EXA*)pAuthData;
			PackageListA = (const char*)ad->PackageList;
			PackageListLength = ad->PackageListLength;
		}

		if (PackageListA && PackageListLength)
		{
			PackageList = _strdup(PackageListA);
		}
	}
	else if ((identityFlags & SEC_WINNT_AUTH_IDENTITY_UNICODE) != 0)
	{
		if (version == SEC_WINNT_AUTH_IDENTITY_VERSION)
		{
			const SEC_WINNT_AUTH_IDENTITY_EXW* ad = (const SEC_WINNT_AUTH_IDENTITY_EXW*)pAuthData;
			PackageListW = (const WCHAR*)ad->PackageList;
			PackageListLength = ad->PackageListLength;
		}
		else if (version == SEC_WINNT_AUTH_IDENTITY_VERSION_2)
		{
			const SEC_WINNT_AUTH_IDENTITY_EX2* ad = (const SEC_WINNT_AUTH_IDENTITY_EX2*)pAuthData;
			PackageListOffset = ad->PackageListOffset;
			PackageListW = WINPR_PACKED_ALIGN_CAST(const WCHAR*,
			                                       &((const uint8_t*)pAuthData)[PackageListOffset]);
			PackageListLength = ad->PackageListLength / 2;
		}

		if (PackageListW && (PackageListLength > 0))
			PackageList = ConvertWCharNToUtf8Alloc(PackageListW, PackageListLength, nullptr);
	}

	if (PackageList)
	{
		*pPackageList = PackageList;
		return TRUE;
	}

	return FALSE;
}

int sspi_CopyAuthIdentity(SEC_WINNT_AUTH_IDENTITY* identity,
                          const SEC_WINNT_AUTH_IDENTITY_INFO* srcIdentity)
{
	int status = 0;
	UINT32 identityFlags = 0;
	const char* UserA = nullptr;
	const char* DomainA = nullptr;
	const char* PasswordA = nullptr;
	const WCHAR* UserW = nullptr;
	const WCHAR* DomainW = nullptr;
	const WCHAR* PasswordW = nullptr;
	UINT32 UserLength = 0;
	UINT32 DomainLength = 0;
	UINT32 PasswordLength = 0;

	sspi_FreeAuthIdentity(identity);

	identityFlags = sspi_GetAuthIdentityFlags(srcIdentity);

	identity->Flags = identityFlags;

	if ((identityFlags & SEC_WINNT_AUTH_IDENTITY_ANSI) != 0)
	{
		if (!sspi_GetAuthIdentityUserDomainA(srcIdentity, &UserA, &UserLength, &DomainA,
		                                     &DomainLength))
		{
			return -1;
		}

		if (!sspi_GetAuthIdentityPasswordA(srcIdentity, &PasswordA, &PasswordLength))
		{
			return -1;
		}

		status = sspi_SetAuthIdentity(identity, UserA, DomainA, PasswordA);

		if (status <= 0)
			return -1;

		identity->Flags &= (uint32_t)~SEC_WINNT_AUTH_IDENTITY_ANSI;
		identity->Flags |= SEC_WINNT_AUTH_IDENTITY_UNICODE;
		return 1;
	}

	identity->Flags |= SEC_WINNT_AUTH_IDENTITY_UNICODE;

	if (!sspi_GetAuthIdentityUserDomainW(srcIdentity, &UserW, &UserLength, &DomainW, &DomainLength))
	{
		return -1;
	}

	if (!sspi_GetAuthIdentityPasswordW(srcIdentity, &PasswordW, &PasswordLength))
	{
		return -1;
	}

	/* login/password authentication */
	identity->UserLength = UserLength;

	if (identity->UserLength > 0)
	{
		identity->User = (UINT16*)calloc((identity->UserLength + 1), sizeof(WCHAR));

		if (!identity->User)
			return -1;

		CopyMemory(identity->User, UserW, identity->UserLength * sizeof(WCHAR));
		identity->User[identity->UserLength] = 0;
	}

	identity->DomainLength = DomainLength;

	if (identity->DomainLength > 0)
	{
		identity->Domain = (UINT16*)calloc((identity->DomainLength + 1), sizeof(WCHAR));

		if (!identity->Domain)
			return -1;

		CopyMemory(identity->Domain, DomainW, identity->DomainLength * sizeof(WCHAR));
		identity->Domain[identity->DomainLength] = 0;
	}

	identity->PasswordLength = PasswordLength;

	if (PasswordW)
	{
		identity->Password = (UINT16*)calloc((identity->PasswordLength + 1), sizeof(WCHAR));

		if (!identity->Password)
			return -1;

		CopyMemory(identity->Password, PasswordW, identity->PasswordLength * sizeof(WCHAR));
		identity->Password[identity->PasswordLength] = 0;
	}

	/* End of login/password authentication */
	return 1;
}

PSecBuffer sspi_FindSecBuffer(PSecBufferDesc pMessage, ULONG BufferType)
{
	PSecBuffer pSecBuffer = nullptr;

	for (UINT32 index = 0; index < pMessage->cBuffers; index++)
	{
		if (pMessage->pBuffers[index].BufferType == BufferType)
		{
			pSecBuffer = &pMessage->pBuffers[index];
			break;
		}
	}

	return pSecBuffer;
}

static BOOL WINPR_init(void)
{

	for (size_t x = 0; x < ARRAYSIZE(SecurityFunctionTableA_NAME_LIST); x++)
	{
		const SecurityFunctionTableA_NAME* cur = &SecurityFunctionTableA_NAME_LIST[x];
		InitializeConstWCharFromUtf8(cur->Name, BUFFER_NAME_LIST_W[x],
		                             ARRAYSIZE(BUFFER_NAME_LIST_W[x]));
	}
	return TRUE;
}

static BOOL CALLBACK sspi_init(WINPR_ATTR_UNUSED PINIT_ONCE InitOnce,
                               WINPR_ATTR_UNUSED PVOID Parameter, WINPR_ATTR_UNUSED PVOID* Context)
{
	if (!winpr_InitializeSSL(WINPR_SSL_INIT_DEFAULT))
		return FALSE;
	if (sspi_ContextBufferAllocTableNew() < 0)
		return FALSE;
	if (!SCHANNEL_init())
		return FALSE;
	if (!KERBEROS_init())
		return FALSE;
	if (!NTLM_init())
		return FALSE;
	if (!CREDSSP_init())
		return FALSE;
	if (!NEGOTIATE_init())
		return FALSE;
	return WINPR_init();
}

void sspi_GlobalInit(void)
{
	static INIT_ONCE once = INIT_ONCE_STATIC_INIT;
	DWORD flags = 0;

	/* Dispatch indexes these lists with SSPI_PACKAGE_ID - 1, so every one of them must have
	 * exactly one entry per package, in the order the enum declares. Adding a package to the
	 * enum without extending all four lists (and the W name buffers) would otherwise read past
	 * the end or dispatch to the wrong package, silently. */
	WINPR_STATIC_ASSERT(ARRAYSIZE(SecPkgInfoA_LIST) == SSPI_PACKAGE_COUNT - 1);
	WINPR_STATIC_ASSERT(ARRAYSIZE(SecPkgInfoW_LIST) == SSPI_PACKAGE_COUNT - 1);
	WINPR_STATIC_ASSERT(ARRAYSIZE(SecurityFunctionTableA_NAME_LIST) == SSPI_PACKAGE_COUNT - 1);
	WINPR_STATIC_ASSERT(ARRAYSIZE(SecurityFunctionTableW_NAME_LIST) == SSPI_PACKAGE_COUNT - 1);
	WINPR_STATIC_ASSERT(ARRAYSIZE(BUFFER_NAME_LIST_W) == SSPI_PACKAGE_COUNT - 1);

	if (!InitOnceExecuteOnce(&once, sspi_init, &flags, nullptr))
		WLog_ERR(TAG, "InitOnceExecuteOnce failed");
}

void sspi_GlobalFinish(void)
{
	sspi_ContextBufferAllocTableFree();
}

static const SecurityFunctionTableA* sspi_GetSecurityFunctionTableAByNameA(const SEC_CHAR* Name)
{
	size_t cPackages = ARRAYSIZE(SecPkgInfoA_LIST);

	for (size_t index = 0; index < cPackages; index++)
	{
		if (strcmp(Name, SecurityFunctionTableA_NAME_LIST[index].Name) == 0)
		{
			return SecurityFunctionTableA_NAME_LIST[index].SecurityFunctionTable;
		}
	}

	return nullptr;
}

static const SecurityFunctionTableW* sspi_GetSecurityFunctionTableWByNameW(const SEC_WCHAR* Name)
{
	size_t cPackages = ARRAYSIZE(SecPkgInfoW_LIST);

	for (size_t index = 0; index < cPackages; index++)
	{
		if (_wcscmp(Name, SecurityFunctionTableW_NAME_LIST[index].Name) == 0)
		{
			return SecurityFunctionTableW_NAME_LIST[index].SecurityFunctionTable;
		}
	}

	return nullptr;
}

/* Table lookup for the context/credential dispatch wrappers, which identify their package
 * by the handle itself. Takes the handle rather than an index so the identifier is read in
 * one place instead of at every call site. */
WINPR_ATTR_NODISCARD static const SecurityFunctionTableA*
sspi_GetSecurityFunctionTableAByHandle(SecHandle* handle)
{
	const SSPI_PACKAGE_ID id = sspi_SecureHandleGetPackageId(handle);

	if ((id < SSPI_PACKAGE_NTLM) || (id > ARRAYSIZE(SecurityFunctionTableA_NAME_LIST)))
		return nullptr;

	return SecurityFunctionTableA_NAME_LIST[id - 1].SecurityFunctionTable;
}

WINPR_ATTR_NODISCARD static const SecurityFunctionTableW*
sspi_GetSecurityFunctionTableWByHandle(SecHandle* handle)
{
	const SSPI_PACKAGE_ID id = sspi_SecureHandleGetPackageId(handle);

	if ((id < SSPI_PACKAGE_NTLM) || (id > ARRAYSIZE(SecurityFunctionTableW_NAME_LIST)))
		return nullptr;

	return SecurityFunctionTableW_NAME_LIST[id - 1].SecurityFunctionTable;
}

static void FreeContextBuffer_EnumerateSecurityPackages(void* contextBuffer);
static void FreeContextBuffer_QuerySecurityPackageInfo(void* contextBuffer);

void sspi_ContextBufferFree(void* contextBuffer)
{
	UINT32 allocatorIndex = 0;

	EnterCriticalSection(&ContextBufferAllocTableLock);

	for (size_t index = 0; index < ContextBufferAllocTable.cMaxEntries; index++)
	{
		if (contextBuffer == ContextBufferAllocTable.entries[index].contextBuffer)
		{
			contextBuffer = ContextBufferAllocTable.entries[index].contextBuffer;
			allocatorIndex = ContextBufferAllocTable.entries[index].allocatorIndex;
			ContextBufferAllocTable.cEntries--;
			ContextBufferAllocTable.entries[index].allocatorIndex = 0;
			ContextBufferAllocTable.entries[index].contextBuffer = nullptr;

			switch (allocatorIndex)
			{
				case EnumerateSecurityPackagesIndex:
					FreeContextBuffer_EnumerateSecurityPackages(contextBuffer);
					break;

				case QuerySecurityPackageInfoIndex:
					FreeContextBuffer_QuerySecurityPackageInfo(contextBuffer);
					break;
				default:
					break;
			}
		}
	}

	LeaveCriticalSection(&ContextBufferAllocTableLock);
}

/**
 * Standard SSPI API
 */

/* Package Management */

static SECURITY_STATUS SEC_ENTRY winpr_EnumerateSecurityPackagesW(ULONG* pcPackages,
                                                                  PSecPkgInfoW* ppPackageInfo)
{
	const size_t cPackages = ARRAYSIZE(SecPkgInfoW_LIST);
	const size_t size = sizeof(SecPkgInfoW) * cPackages;
	SecPkgInfoW* pPackageInfo =
	    (SecPkgInfoW*)sspi_ContextBufferAlloc(EnumerateSecurityPackagesIndex, size);

	WINPR_ASSERT(cPackages <= UINT32_MAX);

	if (!pPackageInfo)
		return SEC_E_INSUFFICIENT_MEMORY;

	for (size_t index = 0; index < cPackages; index++)
	{
		pPackageInfo[index].fCapabilities = SecPkgInfoW_LIST[index]->fCapabilities;
		pPackageInfo[index].wVersion = SecPkgInfoW_LIST[index]->wVersion;
		pPackageInfo[index].wRPCID = SecPkgInfoW_LIST[index]->wRPCID;
		pPackageInfo[index].cbMaxToken = SecPkgInfoW_LIST[index]->cbMaxToken;
		pPackageInfo[index].Name = _wcsdup(SecPkgInfoW_LIST[index]->Name);
		pPackageInfo[index].Comment = _wcsdup(SecPkgInfoW_LIST[index]->Comment);
	}

	*(pcPackages) = (UINT32)cPackages;
	*(ppPackageInfo) = pPackageInfo;
	return SEC_E_OK;
}

static SECURITY_STATUS SEC_ENTRY winpr_EnumerateSecurityPackagesA(ULONG* pcPackages,
                                                                  PSecPkgInfoA* ppPackageInfo)
{
	const size_t cPackages = ARRAYSIZE(SecPkgInfoA_LIST);
	const size_t size = sizeof(SecPkgInfoA) * cPackages;
	SecPkgInfoA* pPackageInfo =
	    (SecPkgInfoA*)sspi_ContextBufferAlloc(EnumerateSecurityPackagesIndex, size);

	WINPR_ASSERT(cPackages <= UINT32_MAX);

	if (!pPackageInfo)
		return SEC_E_INSUFFICIENT_MEMORY;

	for (size_t index = 0; index < cPackages; index++)
	{
		pPackageInfo[index].fCapabilities = SecPkgInfoA_LIST[index]->fCapabilities;
		pPackageInfo[index].wVersion = SecPkgInfoA_LIST[index]->wVersion;
		pPackageInfo[index].wRPCID = SecPkgInfoA_LIST[index]->wRPCID;
		pPackageInfo[index].cbMaxToken = SecPkgInfoA_LIST[index]->cbMaxToken;
		pPackageInfo[index].Name = _strdup(SecPkgInfoA_LIST[index]->Name);
		pPackageInfo[index].Comment = _strdup(SecPkgInfoA_LIST[index]->Comment);

		if (!pPackageInfo[index].Name || !pPackageInfo[index].Comment)
		{
			sspi_ContextBufferFree(pPackageInfo);
			return SEC_E_INSUFFICIENT_MEMORY;
		}
	}

	*(pcPackages) = (UINT32)cPackages;
	*(ppPackageInfo) = pPackageInfo;
	return SEC_E_OK;
}

static void FreeContextBuffer_EnumerateSecurityPackages(void* contextBuffer)
{
	SecPkgInfoA* pPackageInfo = (SecPkgInfoA*)contextBuffer;
	size_t cPackages = ARRAYSIZE(SecPkgInfoA_LIST);

	if (!pPackageInfo)
		return;

	for (size_t index = 0; index < cPackages; index++)
	{
		free(pPackageInfo[index].Name);
		free(pPackageInfo[index].Comment);
	}

	free(pPackageInfo);
}

static SECURITY_STATUS SEC_ENTRY winpr_QuerySecurityPackageInfoW(SEC_WCHAR* pszPackageName,
                                                                 PSecPkgInfoW* ppPackageInfo)
{
	size_t cPackages = ARRAYSIZE(SecPkgInfoW_LIST);

	for (size_t index = 0; index < cPackages; index++)
	{
		if (_wcscmp(pszPackageName, SecPkgInfoW_LIST[index]->Name) == 0)
		{
			size_t size = sizeof(SecPkgInfoW);
			SecPkgInfoW* pPackageInfo =
			    (SecPkgInfoW*)sspi_ContextBufferAlloc(QuerySecurityPackageInfoIndex, size);

			if (!pPackageInfo)
				return SEC_E_INSUFFICIENT_MEMORY;

			pPackageInfo->fCapabilities = SecPkgInfoW_LIST[index]->fCapabilities;
			pPackageInfo->wVersion = SecPkgInfoW_LIST[index]->wVersion;
			pPackageInfo->wRPCID = SecPkgInfoW_LIST[index]->wRPCID;
			pPackageInfo->cbMaxToken = SecPkgInfoW_LIST[index]->cbMaxToken;
			pPackageInfo->Name = _wcsdup(SecPkgInfoW_LIST[index]->Name);
			pPackageInfo->Comment = _wcsdup(SecPkgInfoW_LIST[index]->Comment);
			*(ppPackageInfo) = pPackageInfo;
			return SEC_E_OK;
		}
	}

	*(ppPackageInfo) = nullptr;
	return SEC_E_SECPKG_NOT_FOUND;
}

static SECURITY_STATUS SEC_ENTRY winpr_QuerySecurityPackageInfoA(SEC_CHAR* pszPackageName,
                                                                 PSecPkgInfoA* ppPackageInfo)
{
	size_t cPackages = ARRAYSIZE(SecPkgInfoA_LIST);

	for (size_t index = 0; index < cPackages; index++)
	{
		if (strcmp(pszPackageName, SecPkgInfoA_LIST[index]->Name) == 0)
		{
			size_t size = sizeof(SecPkgInfoA);
			SecPkgInfoA* pPackageInfo =
			    (SecPkgInfoA*)sspi_ContextBufferAlloc(QuerySecurityPackageInfoIndex, size);

			if (!pPackageInfo)
				return SEC_E_INSUFFICIENT_MEMORY;

			pPackageInfo->fCapabilities = SecPkgInfoA_LIST[index]->fCapabilities;
			pPackageInfo->wVersion = SecPkgInfoA_LIST[index]->wVersion;
			pPackageInfo->wRPCID = SecPkgInfoA_LIST[index]->wRPCID;
			pPackageInfo->cbMaxToken = SecPkgInfoA_LIST[index]->cbMaxToken;
			pPackageInfo->Name = _strdup(SecPkgInfoA_LIST[index]->Name);
			pPackageInfo->Comment = _strdup(SecPkgInfoA_LIST[index]->Comment);

			if (!pPackageInfo->Name || !pPackageInfo->Comment)
			{
				sspi_ContextBufferFree(pPackageInfo);
				return SEC_E_INSUFFICIENT_MEMORY;
			}

			*(ppPackageInfo) = pPackageInfo;
			return SEC_E_OK;
		}
	}

	*(ppPackageInfo) = nullptr;
	return SEC_E_SECPKG_NOT_FOUND;
}

void FreeContextBuffer_QuerySecurityPackageInfo(void* contextBuffer)
{
	SecPkgInfo* pPackageInfo = (SecPkgInfo*)contextBuffer;

	if (!pPackageInfo)
		return;

	free(pPackageInfo->Name);
	free(pPackageInfo->Comment);
	free(pPackageInfo);
}

#define log_status(what, status) log_status_((what), (status), __FILE__, __func__, __LINE__)
static SECURITY_STATUS log_status_(const char* what, SECURITY_STATUS status, const char* file,
                                   const char* fkt, size_t line)
{
	if (IsSecurityStatusError(status))
	{
		const DWORD level = WLOG_WARN;
		static wLog* log = nullptr;
		if (!log)
			log = WLog_Get(TAG);

		if (WLog_IsLevelActive(log, level))
		{
			WLog_PrintTextMessage(log, level, line, file, fkt, "%s status %s [0x%08" PRIx32 "]",
			                      what, GetSecurityStatusString(status),
			                      WINPR_CXX_COMPAT_CAST(uint32_t, status));
		}
	}
	return status;
}

/* Credential Management */

static SECURITY_STATUS SEC_ENTRY winpr_AcquireCredentialsHandleW(
    SEC_WCHAR* pszPrincipal, SEC_WCHAR* pszPackage, ULONG fCredentialUse, void* pvLogonID,
    void* pAuthData, SEC_GET_KEY_FN pGetKeyFn, void* pvGetKeyArgument, PCredHandle phCredential,
    PTimeStamp ptsExpiry)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByNameW(pszPackage);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->AcquireCredentialsHandleW)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->AcquireCredentialsHandleW(
	    pszPrincipal, pszPackage, fCredentialUse, pvLogonID, pAuthData, pGetKeyFn, pvGetKeyArgument,
	    phCredential, ptsExpiry);
	return log_status("AcquireCredentialsHandleW", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_AcquireCredentialsHandleA(
    SEC_CHAR* pszPrincipal, SEC_CHAR* pszPackage, ULONG fCredentialUse, void* pvLogonID,
    void* pAuthData, SEC_GET_KEY_FN pGetKeyFn, void* pvGetKeyArgument, PCredHandle phCredential,
    PTimeStamp ptsExpiry)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByNameA(pszPackage);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->AcquireCredentialsHandleA)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->AcquireCredentialsHandleA(
	    pszPrincipal, pszPackage, fCredentialUse, pvLogonID, pAuthData, pGetKeyFn, pvGetKeyArgument,
	    phCredential, ptsExpiry);
	return log_status("AcquireCredentialsHandleA", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_ExportSecurityContext(PCtxtHandle phContext, ULONG fFlags,
                                                             PSecBuffer pPackedContext,
                                                             HANDLE* pToken)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->ExportSecurityContext)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status =
	    table->ExportSecurityContext(phContext, fFlags, pPackedContext, pToken);
	return log_status("ExportSecurityContext", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_FreeCredentialsHandle(PCredHandle phCredential)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phCredential);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->FreeCredentialsHandle)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->FreeCredentialsHandle(phCredential);
	return log_status("FreeCredentialsHandle", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_ImportSecurityContextW(SEC_WCHAR* pszPackage,
                                                              PSecBuffer pPackedContext,
                                                              HANDLE pToken, PCtxtHandle phContext)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->ImportSecurityContextW)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status =
	    table->ImportSecurityContextW(pszPackage, pPackedContext, pToken, phContext);
	return log_status("ImportSecurityContextW", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_ImportSecurityContextA(SEC_CHAR* pszPackage,
                                                              PSecBuffer pPackedContext,
                                                              HANDLE pToken, PCtxtHandle phContext)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->ImportSecurityContextA)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status =
	    table->ImportSecurityContextA(pszPackage, pPackedContext, pToken, phContext);
	return log_status("ImportSecurityContextA", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_QueryCredentialsAttributesW(PCredHandle phCredential,
                                                                   ULONG ulAttribute, void* pBuffer)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phCredential);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->QueryCredentialsAttributesW)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->QueryCredentialsAttributesW(phCredential, ulAttribute, pBuffer);
	return log_status("QueryCredentialsAttributesW", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_QueryCredentialsAttributesA(PCredHandle phCredential,
                                                                   ULONG ulAttribute, void* pBuffer)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phCredential);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->QueryCredentialsAttributesA)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->QueryCredentialsAttributesA(phCredential, ulAttribute, pBuffer);
	return log_status("QueryCredentialsAttributesA", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_SetCredentialsAttributesW(PCredHandle phCredential,
                                                                 ULONG ulAttribute, void* pBuffer,
                                                                 ULONG cbBuffer)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phCredential);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->SetCredentialsAttributesW)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status =
	    table->SetCredentialsAttributesW(phCredential, ulAttribute, pBuffer, cbBuffer);
	return log_status("SetCredentialsAttributesW", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_SetCredentialsAttributesA(PCredHandle phCredential,
                                                                 ULONG ulAttribute, void* pBuffer,
                                                                 ULONG cbBuffer)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phCredential);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->SetCredentialsAttributesA)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status =
	    table->SetCredentialsAttributesA(phCredential, ulAttribute, pBuffer, cbBuffer);
	return log_status("SetCredentialsAttributesA", status);
}

/* Context Management */

static SECURITY_STATUS SEC_ENTRY
winpr_AcceptSecurityContext(PCredHandle phCredential, PCtxtHandle phContext, PSecBufferDesc pInput,
                            ULONG fContextReq, ULONG TargetDataRep, PCtxtHandle phNewContext,
                            PSecBufferDesc pOutput, PULONG pfContextAttr, PTimeStamp ptsTimeStamp)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phCredential);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->AcceptSecurityContext)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status =
	    table->AcceptSecurityContext(phCredential, phContext, pInput, fContextReq, TargetDataRep,
	                                 phNewContext, pOutput, pfContextAttr, ptsTimeStamp);
	return log_status("AcceptSecurityContext", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_ApplyControlToken(PCtxtHandle phContext,
                                                         PSecBufferDesc pInput)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->ApplyControlToken)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->ApplyControlToken(phContext, pInput);
	return log_status("ApplyControlToken", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_CompleteAuthToken(PCtxtHandle phContext,
                                                         PSecBufferDesc pToken)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->CompleteAuthToken)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->CompleteAuthToken(phContext, pToken);
	return log_status("CompleteAuthToken", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_DeleteSecurityContext(PCtxtHandle phContext)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->DeleteSecurityContext)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	const SECURITY_STATUS status = table->DeleteSecurityContext(phContext);
	return log_status("DeleteSecurityContext", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_FreeContextBuffer(void* pvContextBuffer)
{
	if (!pvContextBuffer)
		return SEC_E_INVALID_HANDLE;

	sspi_ContextBufferFree(pvContextBuffer);
	return SEC_E_OK;
}

static SECURITY_STATUS SEC_ENTRY winpr_ImpersonateSecurityContext(PCtxtHandle phContext)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->ImpersonateSecurityContext)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->ImpersonateSecurityContext(phContext);
	return log_status("ImpersonateSecurityContext", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_InitializeSecurityContextW(
    PCredHandle phCredential, PCtxtHandle phContext, SEC_WCHAR* pszTargetName, ULONG fContextReq,
    ULONG Reserved1, ULONG TargetDataRep, PSecBufferDesc pInput, ULONG Reserved2,
    PCtxtHandle phNewContext, PSecBufferDesc pOutput, PULONG pfContextAttr, PTimeStamp ptsExpiry)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phCredential);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->InitializeSecurityContextW)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	const SECURITY_STATUS status = table->InitializeSecurityContextW(
	    phCredential, phContext, pszTargetName, fContextReq, Reserved1, TargetDataRep, pInput,
	    Reserved2, phNewContext, pOutput, pfContextAttr, ptsExpiry);
	return log_status("InitializeSecurityContextW", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_InitializeSecurityContextA(
    PCredHandle phCredential, PCtxtHandle phContext, SEC_CHAR* pszTargetName, ULONG fContextReq,
    ULONG Reserved1, ULONG TargetDataRep, PSecBufferDesc pInput, ULONG Reserved2,
    PCtxtHandle phNewContext, PSecBufferDesc pOutput, PULONG pfContextAttr, PTimeStamp ptsExpiry)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phCredential);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->InitializeSecurityContextA)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->InitializeSecurityContextA(
	    phCredential, phContext, pszTargetName, fContextReq, Reserved1, TargetDataRep, pInput,
	    Reserved2, phNewContext, pOutput, pfContextAttr, ptsExpiry);

	return log_status("InitializeSecurityContextA", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_QueryContextAttributesW(PCtxtHandle phContext,
                                                               ULONG ulAttribute, void* pBuffer)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->QueryContextAttributesW)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->QueryContextAttributesW(phContext, ulAttribute, pBuffer);
	return log_status("QueryContextAttributesW", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_QueryContextAttributesA(PCtxtHandle phContext,
                                                               ULONG ulAttribute, void* pBuffer)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->QueryContextAttributesA)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->QueryContextAttributesA(phContext, ulAttribute, pBuffer);
	return log_status("QueryContextAttributesA", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_QuerySecurityContextToken(PCtxtHandle phContext,
                                                                 HANDLE* phToken)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->QuerySecurityContextToken)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->QuerySecurityContextToken(phContext, phToken);
	return log_status("QuerySecurityContextToken", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_SetContextAttributesW(PCtxtHandle phContext,
                                                             ULONG ulAttribute, void* pBuffer,
                                                             ULONG cbBuffer)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->SetContextAttributesW)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status =
	    table->SetContextAttributesW(phContext, ulAttribute, pBuffer, cbBuffer);
	return log_status("SetContextAttributesW", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_SetContextAttributesA(PCtxtHandle phContext,
                                                             ULONG ulAttribute, void* pBuffer,
                                                             ULONG cbBuffer)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->SetContextAttributesA)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status =
	    table->SetContextAttributesA(phContext, ulAttribute, pBuffer, cbBuffer);
	return log_status("SetContextAttributesA", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_RevertSecurityContext(PCtxtHandle phContext)
{
	const SecurityFunctionTableW* table = sspi_GetSecurityFunctionTableWByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->RevertSecurityContext)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->RevertSecurityContext(phContext);

	return log_status("RevertSecurityContext", status);
}

/* Message Support */

static SECURITY_STATUS SEC_ENTRY winpr_DecryptMessage(PCtxtHandle phContext,
                                                      PSecBufferDesc pMessage, ULONG MessageSeqNo,
                                                      PULONG pfQOP)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->DecryptMessage)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	const SECURITY_STATUS status = table->DecryptMessage(phContext, pMessage, MessageSeqNo, pfQOP);

	return log_status("DecryptMessage", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_EncryptMessage(PCtxtHandle phContext, ULONG fQOP,
                                                      PSecBufferDesc pMessage, ULONG MessageSeqNo)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->EncryptMessage)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	const SECURITY_STATUS status = table->EncryptMessage(phContext, fQOP, pMessage, MessageSeqNo);
	return log_status("EncryptMessage", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_MakeSignature(PCtxtHandle phContext, ULONG fQOP,
                                                     PSecBufferDesc pMessage, ULONG MessageSeqNo)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->MakeSignature)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	const SECURITY_STATUS status = table->MakeSignature(phContext, fQOP, pMessage, MessageSeqNo);
	return log_status("MakeSignature", status);
}

static SECURITY_STATUS SEC_ENTRY winpr_VerifySignature(PCtxtHandle phContext,
                                                       PSecBufferDesc pMessage, ULONG MessageSeqNo,
                                                       PULONG pfQOP)
{
	const SecurityFunctionTableA* table = sspi_GetSecurityFunctionTableAByHandle(phContext);

	if (!table)
		return SEC_E_SECPKG_NOT_FOUND;

	if (!table->VerifySignature)
	{
		WLog_WARN(TAG, "Security module does not provide an implementation");
		return SEC_E_UNSUPPORTED_FUNCTION;
	}

	SECURITY_STATUS status = table->VerifySignature(phContext, pMessage, MessageSeqNo, pfQOP);

	return log_status("VerifySignature", status);
}

static SecurityFunctionTableA winpr_SecurityFunctionTableA = {
	3,                                 /* dwVersion */
	winpr_EnumerateSecurityPackagesA,  /* EnumerateSecurityPackages */
	winpr_QueryCredentialsAttributesA, /* QueryCredentialsAttributes */
	winpr_AcquireCredentialsHandleA,   /* AcquireCredentialsHandle */
	winpr_FreeCredentialsHandle,       /* FreeCredentialsHandle */
	nullptr,                           /* Reserved2 */
	winpr_InitializeSecurityContextA,  /* InitializeSecurityContext */
	winpr_AcceptSecurityContext,       /* AcceptSecurityContext */
	winpr_CompleteAuthToken,           /* CompleteAuthToken */
	winpr_DeleteSecurityContext,       /* DeleteSecurityContext */
	winpr_ApplyControlToken,           /* ApplyControlToken */
	winpr_QueryContextAttributesA,     /* QueryContextAttributes */
	winpr_ImpersonateSecurityContext,  /* ImpersonateSecurityContext */
	winpr_RevertSecurityContext,       /* RevertSecurityContext */
	winpr_MakeSignature,               /* MakeSignature */
	winpr_VerifySignature,             /* VerifySignature */
	winpr_FreeContextBuffer,           /* FreeContextBuffer */
	winpr_QuerySecurityPackageInfoA,   /* QuerySecurityPackageInfo */
	nullptr,                           /* Reserved3 */
	nullptr,                           /* Reserved4 */
	winpr_ExportSecurityContext,       /* ExportSecurityContext */
	winpr_ImportSecurityContextA,      /* ImportSecurityContext */
	nullptr,                           /* AddCredentials */
	nullptr,                           /* Reserved8 */
	winpr_QuerySecurityContextToken,   /* QuerySecurityContextToken */
	winpr_EncryptMessage,              /* EncryptMessage */
	winpr_DecryptMessage,              /* DecryptMessage */
	winpr_SetContextAttributesA,       /* SetContextAttributes */
	winpr_SetCredentialsAttributesA,   /* SetCredentialsAttributes */
};

static SecurityFunctionTableW winpr_SecurityFunctionTableW = {
	3,                                 /* dwVersion */
	winpr_EnumerateSecurityPackagesW,  /* EnumerateSecurityPackages */
	winpr_QueryCredentialsAttributesW, /* QueryCredentialsAttributes */
	winpr_AcquireCredentialsHandleW,   /* AcquireCredentialsHandle */
	winpr_FreeCredentialsHandle,       /* FreeCredentialsHandle */
	nullptr,                           /* Reserved2 */
	winpr_InitializeSecurityContextW,  /* InitializeSecurityContext */
	winpr_AcceptSecurityContext,       /* AcceptSecurityContext */
	winpr_CompleteAuthToken,           /* CompleteAuthToken */
	winpr_DeleteSecurityContext,       /* DeleteSecurityContext */
	winpr_ApplyControlToken,           /* ApplyControlToken */
	winpr_QueryContextAttributesW,     /* QueryContextAttributes */
	winpr_ImpersonateSecurityContext,  /* ImpersonateSecurityContext */
	winpr_RevertSecurityContext,       /* RevertSecurityContext */
	winpr_MakeSignature,               /* MakeSignature */
	winpr_VerifySignature,             /* VerifySignature */
	winpr_FreeContextBuffer,           /* FreeContextBuffer */
	winpr_QuerySecurityPackageInfoW,   /* QuerySecurityPackageInfo */
	nullptr,                           /* Reserved3 */
	nullptr,                           /* Reserved4 */
	winpr_ExportSecurityContext,       /* ExportSecurityContext */
	winpr_ImportSecurityContextW,      /* ImportSecurityContext */
	nullptr,                           /* AddCredentials */
	nullptr,                           /* Reserved8 */
	winpr_QuerySecurityContextToken,   /* QuerySecurityContextToken */
	winpr_EncryptMessage,              /* EncryptMessage */
	winpr_DecryptMessage,              /* DecryptMessage */
	winpr_SetContextAttributesW,       /* SetContextAttributes */
	winpr_SetCredentialsAttributesW,   /* SetCredentialsAttributes */
};

SecurityFunctionTableW* SEC_ENTRY winpr_InitSecurityInterfaceW(void)
{
	return &winpr_SecurityFunctionTableW;
}

SecurityFunctionTableA* SEC_ENTRY winpr_InitSecurityInterfaceA(void)
{
	return &winpr_SecurityFunctionTableA;
}

SEC_WINPR_NTLM_SETTINGS_V2* sspi_CloneSecNtlmSettings(const SEC_WINPR_NTLM_SETTINGS_V2* other)
{
	if (!other)
		return nullptr;

	const size_t size = sizeof(SEC_WINPR_NTLM_SETTINGS_V2);
	if (other->size < size)
	{
		WLog_ERR(TAG,
		         "Invalid SEC_WINPR_NTLM_SETTINGS_V2 parameter passed, must be of size >= "
		         "%" PRIuz,
		         size);
		return nullptr;
	}

	SEC_WINPR_NTLM_SETTINGS_V2* clone = sspi_AllocSecNtlmSettings();
	if (!clone)
		return nullptr;

	if (other->samFile)
	{
		if (!sspi_CloneSecSettingsString(&clone->samFile, other->samFile))
			goto fail;
	}
	clone->hashCallback = other->hashCallback;
	clone->hashCallbackArg = other->hashCallbackArg;
	if (other->targetName)
	{
		if (!sspi_CloneSecSettingsString(&clone->targetName, other->targetName))
			goto fail;
	}
	if (other->netBiosComputerName)
	{
		if (!sspi_CloneSecSettingsString(&clone->netBiosComputerName, other->netBiosComputerName))
			goto fail;
	}
	if (other->netBiosDomainName)
	{
		if (!sspi_CloneSecSettingsString(&clone->netBiosDomainName, other->netBiosDomainName))
			goto fail;
	}
	if (other->dnsComputerName)
	{
		if (!sspi_CloneSecSettingsString(&clone->dnsComputerName, other->dnsComputerName))
			goto fail;
	}
	if (other->dnsDomainName)
	{
		if (!sspi_CloneSecSettingsString(&clone->dnsDomainName, other->dnsDomainName))
			goto fail;
	}

	return clone;

fail:
	sspi_FreeSecNtlmSettings(clone);
	return nullptr;
}

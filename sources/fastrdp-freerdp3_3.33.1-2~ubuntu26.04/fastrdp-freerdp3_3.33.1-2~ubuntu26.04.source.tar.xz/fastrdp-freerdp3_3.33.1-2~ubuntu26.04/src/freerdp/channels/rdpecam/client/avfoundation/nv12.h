/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * MS-RDPECAM AVFoundation native NV12 samples.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef FREERDP_RDPECAM_AVFOUNDATION_NV12_H
#define FREERDP_RDPECAM_AVFOUNDATION_NV12_H

#include <CoreVideo/CoreVideo.h>
#include <winpr/stream.h>
#include <freerdp/api.h>

WINPR_ATTR_NODISCARD
FREERDP_LOCAL BOOL cam_avfoundation_pixel_buffer_to_nv12(CVPixelBufferRef image, wStream* output);

WINPR_ATTR_NODISCARD
FREERDP_LOCAL OSStatus cam_avfoundation_pixel_transfer_create(CFTypeRef* transfer)
    API_AVAILABLE(macos(10.8), ios(16.0), tvos(16.0));

#endif
